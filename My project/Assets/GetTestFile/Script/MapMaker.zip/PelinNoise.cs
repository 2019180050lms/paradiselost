using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PelinNoise : MonoBehaviour
{
    float maxheight = float.MaxValue;
    float minheight = float.MinValue;
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log(maxheight + ":" + minheight);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
